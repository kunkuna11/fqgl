# 分区管家 / Partition Pilot

一个面向具备 Root 权限的 Android 设备的分区读取、备份和受限刷写 Android Studio 源码项目。

## 当前功能

- 启动时执行 `su -c id -u` Root 实测；未取得 UID 0 时不开放分区功能。
- 扫描设备实际存在的 `/dev/block` 块设备及 `by-name` / `mapper` 节点，不按厂商或机型写死分区表。
- 显示分区节点、真实容量、逻辑/物理节点识别及只读状态。
- 多选分区备份到 `/storage/emulated/0/TNJZ`，目录不存在时自动创建；备份文件带分区名和时间戳，写入前后检查大小并输出 SHA-256。
- 独立刷写页面：选择分区、通过系统文件选择器选择镜像、计算 SHA-256、二次确认。
- 刷写前自动备份目标分区到 TNJZ；检查镜像大小、哈希、目标块设备只读状态；A/B 设备拒绝写入当前活动槽位或无法确定槽位的槽位分区；写入后回读镜像长度并校验哈希。
- 设备信息使用 Android `Build` API 和 Linux 内核属性读取，包含设备名称、制造商、型号、设备代号、内核版本、Android 版本/API、系统指纹。
- 深浅色背景跟随系统；采用 MIUIX 视觉风格并引入 Miuix Compose UI 依赖。

## 构建方式（Groovy Gradle）

本版本改为传统 `build.gradle` / `settings.gradle` Groovy DSL，不再使用 Kotlin DSL；同时固定为一组相互兼容的构建工具版本，减少插件解析和 Compose 编译器版本冲突。

- Android Studio：建议 Koala Feature Drop 或更新版本
- JDK：17
- Android Gradle Plugin：8.9.2
- Gradle：8.11.1（在 Android Studio 的 Gradle 设置中使用本机安装的）
- Kotlin：2.1.20（Compose Compiler 插件与 Kotlin 同版本）
- Android SDK Platform：35

构建步骤：

1. 解压 ZIP，Android Studio 选择 `Open`，打开 `PartitionPilot` 文件夹（不是 `app` 子文件夹）。
2. 在 Android Studio 的 Gradle JDK 设置中选择 JDK 17。
3. 安装 Android SDK Platform 35 和对应 Build Tools。
4. 等待 Gradle Sync 完成，再选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. 安装后，在 Root 管理器中允许“分区管家”的 Root 请求。

也可先安装 Gradle 8.11.1，然后在项目根目录执行：

```bash
# 可选：生成标准 Gradle Wrapper（只需执行一次）
gradle wrapper --gradle-version 8.11.1

# 构建 Debug APK
gradle assembleDebug
# 若已生成 Wrapper，则使用 ./gradlew assembleDebug
```

输出 APK：`app/build/outputs/apk/debug/app-debug.apk`。

为降低首次构建失败概率，本版移除了原来未参与实际页面控件绘制的 Miuix Compose 运行时依赖；页面仍保留 MIUIX 风格的圆角卡片、渐变入口、颜色体系和跟随系统深浅色的设计。核心 Kotlin 页面、Root 检测、分区扫描、备份、镜像选择、SHA-256 校验、受限刷写与设备信息读取逻辑保持原样。

## 极其重要的限制

**本项目不是“所有 Android 手机所有分区都能刷”的承诺。** Android 厂商分区布局、Bootloader、AVB、动态分区、SELinux 和设备树差异很大。为降低误刷风险，当前通用 raw 写入白名单仅包括常见的 `boot`、`init_boot`、`vendor_boot`、`dtbo`、`recovery` 及 A/B 对应槽位；`super`、`vbmeta`、`system`、`vendor`、基带、持久化数据和 mapper 动态逻辑分区不会通过本流程写入。动态分区请使用设备匹配的官方 `fastbootd`/OTA 流程。

即使分区名称匹配，镜像仍必须与设备型号、硬件修订、Android 版本、槽位和 AVB 链完全匹配。错误镜像仍可能导致无法启动。请在测试设备上验证，并确保有可用的官方救援/刷机方案。

通用 Android 没有可靠标准 API 可查询每个分区的历史刷入时间，因此界面明确显示“Android 未提供可验证记录”，不会伪造时间。备份时间是本软件实际生成备份文件的时间。

## 适配说明

- Root 访问使用系统 `su` 命令，不绑定 Magisk、KernelSU 或 SukiSU 某一个管理器；实际能否授权取决于 Root 管理器策略。
- 分区扫描依赖设备允许 Root shell 访问 `/dev/block`，某些厂商固件会隐藏或限制节点，此时软件会如实显示无法读取。
- Android 版本和厂商对块设备命令支持可能不同。任何命令失败均应视为操作失败，不应跳过校验继续写入。
- 当前工程交付为 Android Studio 源码；本执行环境没有 Android SDK/Gradle 安装，因此没有声称已完成 APK 编译或真机刷写测试。

## 参考项目与规范

- libsu: https://github.com/topjohnwu/libsu
- Miuix: https://github.com/compose-miuix-ui/miuix
- AOSP Dynamic Partitions: https://source.android.com/docs/core/ota/dynamic_partitions/implement
- AOSP Fastbootd: https://source.android.com/docs/core/architecture/bootloader/fastbootd

## v1.0.1 界面与交互修复

- 根页面统一应用安全区域 Insets，主页、分区页、刷写页和 Root 检测页均避开状态栏与底部系统导航区域。
- 分区扫描仍以设备实时块设备节点为数据来源，但列表仅保留内置的 145 个常见分区名称；设备不存在的分区不会显示，结果按名称 A–Z 排序。
- 移除整页 `AnimatedContent` 转场，减少页面切换时的额外布局/动画开销；主页 LazyColumn 项目使用稳定 key。
- 在分区读取页和刷写页启用系统返回键回到主页，主页仍保留系统默认退出行为。
- 保留 Root 检测、镜像选择、SHA-256 校验、分区备份和受限 raw 刷写流程。

## 最简单的编译方式

不想配置 Android Studio/JDK/SDK 时，按项目根目录的《一键云端编译.md》使用 GitHub Actions 编译 APK。云端自动准备构建环境并提供 APK 下载。
