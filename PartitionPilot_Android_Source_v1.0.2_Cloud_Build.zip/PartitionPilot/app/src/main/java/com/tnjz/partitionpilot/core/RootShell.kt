package com.tnjz.partitionpilot.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class ShellResult(val code: Int, val output: String)

object RootShell {
    suspend fun run(command: String, timeoutSeconds: Long = 120): ShellResult = withContext(Dispatchers.IO) {
        val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val output = StringBuilder()
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        val readerThread = Thread { try { reader.forEachLine { output.append(it).append('\n') } } catch (_: Exception) {} }
        readerThread.start()
        val finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
        if (!finished) {
            process.destroyForcibly()
            readerThread.join(1000)
            return@withContext ShellResult(124, output.toString() + "\n操作超时")
        }
        readerThread.join(2000)
        ShellResult(process.exitValue(), output.toString().trim())
    }

    suspend fun hasRoot(): Boolean {
        val result = run("id -u", 12)
        return result.code == 0 && result.output.lineSequence().lastOrNull()?.trim() == "0"
    }
}
