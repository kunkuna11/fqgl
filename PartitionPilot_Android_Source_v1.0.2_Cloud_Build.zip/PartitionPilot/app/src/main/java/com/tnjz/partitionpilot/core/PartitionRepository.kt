package com.tnjz.partitionpilot.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Only actual block devices discovered on this phone are returned. */
data class PartitionInfo(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val isLogical: Boolean,
    val readOnly: Boolean
) {
    val canRawFlash: Boolean get() = !isLogical && !readOnly && name.lowercase(Locale.ROOT) in FLASH_ALLOWLIST
    companion object {
        private val FLASH_ALLOWLIST = setOf(
            "boot", "boot_a", "boot_b", "init_boot", "init_boot_a", "init_boot_b",
            "vendor_boot", "vendor_boot_a", "vendor_boot_b", "dtbo", "dtbo_a", "dtbo_b",
            "recovery", "recovery_a", "recovery_b"
        )
    }
}

object PartitionRepository {
    // 仅展示跨设备常见的 145 个分区名称；仍以本机实时发现结果为准，不伪造不存在的分区。
    private val COMMON_PARTITION_NAMES = setOf(
        "abl",
        "aop",
        "apdp",
        "bluetooth",
        "boot",
        "boot_a",
        "boot_b",
        "cache",
        "carrier",
        "cdsp",
        "cdt",
        "cmnlib",
        "cmnlib64",
        "connsec",
        "ddr",
        "devcfg",
        "devinfo",
        "dip",
        "dsp",
        "dtbo",
        "dtbo_a",
        "dtbo_b",
        "efs",
        "engineering",
        "frp",
        "fsc",
        "fsg",
        "hyp",
        "imagefv",
        "init_boot",
        "init_boot_a",
        "init_boot_b",
        "keymaster",
        "keystore",
        "limits",
        "logfs",
        "logo",
        "mdm1m9kefs1",
        "mdm1m9kefs2",
        "mdm1m9kefs3",
        "metadata",
        "misc",
        "modem",
        "modemst1",
        "modemst2",
        "odm",
        "odm_a",
        "odm_b",
        "oem",
        "oem_a",
        "oem_b",
        "persist",
        "persistbak",
        "product",
        "product_a",
        "product_b",
        "recovery",
        "recovery_a",
        "recovery_b",
        "reserve",
        "rpm",
        "sbl1",
        "sec",
        "splash",
        "spunvm",
        "ssd",
        "system",
        "system_a",
        "system_b",
        "system_ext",
        "system_ext_a",
        "system_ext_b",
        "tz",
        "userdata",
        "vbmeta",
        "vbmeta_a",
        "vbmeta_b",
        "vbmeta_system",
        "vbmeta_system_a",
        "vbmeta_system_b",
        "vbmeta_vendor",
        "vbmeta_vendor_a",
        "vbmeta_vendor_b",
        "vendor",
        "vendor_a",
        "vendor_b",
        "vendor_boot",
        "vendor_boot_a",
        "vendor_boot_b",
        "vendor_dlkm",
        "vendor_dlkm_a",
        "vendor_dlkm_b",
        "xbl",
        "xbl_config",
        "xbl_ramdump",
        "xbl_scuf",
        "xbl_scuf_a",
        "xbl_scuf_b",
        "abl_a",
        "abl_b",
        "aop_a",
        "aop_b",
        "bluetooth_a",
        "bluetooth_b",
        "cache_a",
        "cache_b",
        "cpucp",
        "cpucp_a",
        "cpucp_b",
        "devcfg_a",
        "devcfg_b",
        "devinfo_a",
        "devinfo_b",
        "dsp_a",
        "dsp_b",
        "frp_a",
        "frp_b",
        "hyp_a",
        "hyp_b",
        "imagefv_a",
        "imagefv_b",
        "keymaster_a",
        "keymaster_b",
        "modem_a",
        "modem_b",
        "odm_dlkm",
        "odm_dlkm_a",
        "odm_dlkm_b",
        "product_services",
        "product_services_a",
        "product_services_b",
        "pvmfw",
        "pvmfw_a",
        "pvmfw_b",
        "radio",
        "ramdump",
        "recovery_dtbo",
        "recovery_dtbo_a",
        "recovery_dtbo_b",
        "reserve1",
        "reserve2",
        "rpm_a",
        "rpm_b",
        "sbl1_a",
        "sbl1_b"
    )

    suspend fun scan(): Pair<List<PartitionInfo>, String> {
        val script = """
            find /dev/block \( -type l -o -type b \) -print 2>/dev/null | while IFS= read -r link; do
              case "${'$'}link" in */by-name/*|*/mapper/*) ;; *) continue ;; esac
              target=${'$'}(readlink -f "${'$'}link" 2>/dev/null)
              [ -n "${'$'}target" ] || continue
              [ -b "${'$'}target" ] || continue
              name=${'$'}{link##*/}
              size=${'$'}(blockdev --getsize64 "${'$'}target" 2>/dev/null || { sectors=${'$'}(blockdev --getsize "${'$'}target" 2>/dev/null); [ -n "${'$'}sectors" ] && echo ${'$'}((sectors * 512)) || echo 0; })
              ro=${'$'}(blockdev --getro "${'$'}target" 2>/dev/null || echo unknown)
              printf '%s\t%s\t%s\t%s\n' "${'$'}name" "${'$'}target" "${'$'}size" "${'$'}ro"
            done | sort -u
        """.trimIndent()
        val result = RootShell.run(script, 45)
        if (result.code != 0) return emptyList<PartitionInfo>() to result.output
        val entries = result.output.lineSequence().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 4) return@mapNotNull null
            val name = p[0].trim()
            val path = p[1].trim()
            val size = p[2].trim().toLongOrNull() ?: 0L
            // Fail closed: unknown read-only status is treated as not writable.
            val ro = p[3].trim() != "0"
            if (name.isBlank() || name.lowercase(Locale.ROOT) !in COMMON_PARTITION_NAMES ||
                !path.startsWith("/dev/block/") || size <= 0) return@mapNotNull null
            val logical = path.contains("/mapper/") || path.substringAfterLast('/').startsWith("dm-")
            PartitionInfo(name, path, size, logical, ro)
        }.distinctBy { it.path }
            .sortedWith(compareBy<PartitionInfo> { it.name.lowercase(Locale.ROOT) }.thenBy { it.path })
            .take(145)
            .toList()
        return entries to result.output
    }

    suspend fun backup(partition: PartitionInfo): ShellResult {
        if (!partition.path.startsWith("/dev/block/") || partition.sizeBytes <= 0) return ShellResult(2, "分区信息无效")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeName = partition.name.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        val dir = "/storage/emulated/0/TNJZ"
        val output = "$dir/${safeName}_$stamp.img"
        val tmp = "$output.part"
        val qPath = shQuote(partition.path)
        val qOut = shQuote(output)
        val qTmp = shQuote(tmp)
        val script = """
            set -e
            mkdir -p ${shQuote(dir)}
            chmod 0775 ${shQuote(dir)}
            avail=${'$'}(df -Pk ${shQuote(dir)} | tail -n 1 | awk '{print ${'$'}4 * 1024}')
            need=${partition.sizeBytes}
            [ "${'$'}avail" -ge "${'$'}need" ] || { echo '存储空间不足'; exit 31; }
            rm -f $qTmp
            dd if=$qPath of=$qTmp bs=4M conv=fsync 2>&1
            actual=${'$'}(stat -c %s $qTmp)
            [ "${'$'}actual" -eq "${'$'}need" ] || { echo '备份大小校验失败'; rm -f $qTmp; exit 32; }
            sha256sum $qTmp
            mv $qTmp $qOut
            sync
            echo 'BACKUP_OK'
            echo $qOut
        """.trimIndent()
        return RootShell.run(script, 60 * 60)
    }

    suspend fun flash(partition: PartitionInfo, imagePath: String, imageSize: Long, expectedSha: String): ShellResult {
        if (!partition.canRawFlash) return ShellResult(40, "该分区不在通用安全刷写名单内，已拒绝写入")
        if (!partition.name.matches(Regex("[A-Za-z0-9_.-]+"))) return ShellResult(44, "分区名称包含不支持字符")
        if (!imagePath.startsWith("/data/user/") && !imagePath.startsWith("/data/data/")) return ShellResult(41, "镜像临时路径无效")
        if (imageSize <= 0 || imageSize > partition.sizeBytes) return ShellResult(42, "镜像大小超过分区容量或为空")
        if (!expectedSha.matches(Regex("[a-fA-F0-9]{64}"))) return ShellResult(43, "SHA-256 格式无效")
        val qImage = shQuote(imagePath)
        val qBlock = shQuote(partition.path)
        val script = """
            set -e
            [ -f $qImage ] || { echo '镜像文件不存在'; exit 51; }
            actual_size=${'$'}(stat -c %s $qImage)
            [ "${'$'}actual_size" -eq "$imageSize" ] || { echo '镜像文件大小发生变化'; exit 52; }
            actual_sha=${'$'}(sha256sum $qImage | awk '{print ${'$'}1}')
            [ "${'$'}actual_sha" = "${expectedSha.lowercase(Locale.ROOT)}" ] || { echo '镜像 SHA-256 校验失败'; exit 53; }
            block_size=${'$'}(blockdev --getsize64 $qBlock)
            [ "${'$'}actual_size" -le "${'$'}block_size" ] || { echo '镜像大于目标分区'; exit 54; }
            [ "${'$'}(blockdev --getro $qBlock)" = '0' ] || { echo '目标分区为只读'; exit 55; }
            slot=${'$'}(getprop ro.boot.slot_suffix)
            case '${partition.name}' in
              *_a) [ "${'$'}slot" != '_a' ] && [ -n "${'$'}slot" ] || { echo '拒绝写入当前活动槽位或无法确认槽位'; exit 57; } ;;
              *_b) [ "${'$'}slot" != '_b' ] && [ -n "${'$'}slot" ] || { echo '拒绝写入当前活动槽位或无法确认槽位'; exit 58; } ;;
            esac
            mkdir -p /storage/emulated/0/TNJZ
            backup=/storage/emulated/0/TNJZ/preflash_${partition.name}_${'$'}(date +%Y%m%d_%H%M%S).img
            avail=${'$'}(df -Pk /storage/emulated/0/TNJZ | tail -n 1 | awk '{print ${'$'}4 * 1024}')
            [ "${'$'}avail" -ge "${'$'}block_size" ] || { echo '空间不足，无法先备份目标分区'; exit 59; }
            dd if=$qBlock of="${'$'}backup.part" bs=4M conv=fsync 2>&1
            [ "${'$'}(stat -c %s "${'$'}backup.part")" -eq "${'$'}block_size" ] || { echo '写入前备份失败'; rm -f "${'$'}backup.part"; exit 60; }
            sha256sum "${'$'}backup.part"
            mv "${'$'}backup.part" "${'$'}backup"
            dd if=$qImage of=$qBlock bs=4M conv=fsync 2>&1
            sync
            verify=${'$'}(head -c "${'$'}actual_size" $qBlock | sha256sum | awk '{print ${'$'}1}')
            [ "${'$'}verify" = "${'$'}actual_sha" ] || { echo '写入后回读校验失败'; exit 56; }
            echo 'FLASH_VERIFY_OK'
        """.trimIndent()
        return RootShell.run(script, 60 * 30)
    }

    private fun shQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"
}
