package com.tnjz.partitionpilot

import android.os.Build
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.tnjz.partitionpilot.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        setContent { PartitionPilotApp() }
    }
}

private enum class Page { HOME, PARTITIONS, FLASH }
private data class ImageInfo(val file: File, val size: Long, val sha256: String)

@Composable
private fun PartitionPilotApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF9DBBFF), secondary = Color(0xFF8FD6C0), background = Color(0xFF111923),
        surface = Color(0xFF1B2633), surfaceVariant = Color(0xFF263444), onBackground = Color(0xFFE7EDF7),
        onSurface = Color(0xFFE7EDF7), onSurfaceVariant = Color(0xFFB4C0D0)
    ) else lightColorScheme(
        primary = Color(0xFF286FE8), secondary = Color(0xFF16866C), background = Color(0xFFEAF0F8),
        surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFDDE7F4), onBackground = Color(0xFF18263A),
        onSurface = Color(0xFF18263A), onSurfaceVariant = Color(0xFF65758B)
    )

    var root by remember { mutableStateOf<Boolean?>(null) }
    var page by remember { mutableStateOf(Page.HOME) }
    var partitions by remember { mutableStateOf<List<PartitionInfo>>(emptyList()) }
    var scanBusy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var flashTarget by remember { mutableStateOf<PartitionInfo?>(null) }
    var image by remember { mutableStateOf<ImageInfo?>(null) }
    var typedConfirm by remember { mutableStateOf("") }
    var acknowledged by remember { mutableStateOf(false) }
    var operationBusy by remember { mutableStateOf(false) }
    var operationLog by remember { mutableStateOf("") }

    fun refresh() {
        activity.lifecycleScope.launch {
            scanBusy = true
            val (items, log) = PartitionRepository.scan()
            partitions = items
            if (items.isEmpty()) message = if (log.isBlank()) "未发现可读取的分区节点" else log
            scanBusy = false
        }
    }

    LaunchedEffect(Unit) { root = RootShell.hasRoot() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) activity.lifecycleScope.launch {
            operationBusy = true
            try {
                val file = withContext(Dispatchers.IO) {
                    val dest = File(context.filesDir, "selected_firmware.img")
                    context.contentResolver.openInputStream(uri)!!.use { input -> dest.outputStream().use { input.copyTo(it) } }
                    dest
                }
                val hash = withContext(Dispatchers.IO) { sha256(file) }
                image = ImageInfo(file, file.length(), hash)
                operationLog = "镜像已载入并计算 SHA-256。"
            } catch (e: Exception) { operationLog = "读取镜像失败：${e.message}" }
            operationBusy = false
        }
    }

    androidx.compose.runtime.SideEffect {
        val bar = if (dark) android.graphics.Color.rgb(17, 25, 35) else android.graphics.Color.rgb(234, 240, 248)
        activity.window.statusBarColor = bar
        activity.window.navigationBarColor = bar
        @Suppress("DEPRECATION")
        run {
            activity.window.decorView.systemUiVisibility = if (dark) 0 else
                (android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
    }

    BackHandler(enabled = page != Page.HOME) {
        page = Page.HOME
    }

    MaterialTheme(colorScheme = colors) {
        Surface(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            color = colors.background
        ) {
            if (root != true) {
                RootGate(root = root, onRetry = {
                    activity.lifecycleScope.launch { root = RootShell.hasRoot() }
                })
            } else {
                Column(Modifier.fillMaxSize()) {
                    when (page) {
                            Page.HOME -> HomePage(
                                onPartitions = { page = Page.PARTITIONS; if (partitions.isEmpty()) refresh() },
                                onFlash = { page = Page.FLASH; if (partitions.isEmpty()) refresh() }
                            )
                            Page.PARTITIONS -> PartitionsPage(
                                partitions, selected, scanBusy, message,
                                onBack = { page = Page.HOME }, onRefresh = ::refresh,
                                onToggle = { p, checked -> selected = if (checked) selected + p.path else selected - p.path },
                                onBackup = {
                                    val batch = partitions.filter { it.path in selected }
                                    activity.lifecycleScope.launch {
                                        operationBusy = true; operationLog = "正在备份 ${batch.size} 个分区…"
                                        val logs = mutableListOf<String>()
                                        for (p in batch) {
                                            val r = PartitionRepository.backup(p)
                                            logs += "${p.name}: ${r.output.ifBlank { "exit=${r.code}" }}"
                                            if (r.code != 0) break
                                        }
                                        operationLog = logs.joinToString("\n\n")
                                        operationBusy = false
                                    }
                                }, busy = operationBusy, log = operationLog
                            )
                            Page.FLASH -> FlashPage(
                                partitions = partitions,
                                target = flashTarget,
                                image = image,
                                typedConfirm = typedConfirm,
                                acknowledged = acknowledged,
                                busy = operationBusy,
                                log = operationLog,
                                onBack = { page = Page.HOME },
                                onTarget = { flashTarget = it; typedConfirm = "" },
                                onPickImage = { picker.launch(arrayOf("*/*")) },
                                onTyped = { typedConfirm = it },
                                onAck = { acknowledged = it },
                                onFlash = {
                                    val p = flashTarget; val img = image
                                    if (p != null && img != null) activity.lifecycleScope.launch {
                                        operationBusy = true
                                        operationLog = "正在执行写入和回读校验…请勿关闭应用或重启设备。"
                                        val r = PartitionRepository.flash(p, img.file.absolutePath, img.size, img.sha256)
                                        operationLog = "退出码：${r.code}\n${r.output}"
                                        operationBusy = false
                                    }
                                }
                            )
                    }
                }
            }
        }
    }
}

@Composable
private fun RootGate(root: Boolean?, onRetry: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.background, c.surfaceVariant))), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(92.dp).clip(RoundedCornerShape(30.dp)).background(c.primary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.AdminPanelSettings, null, tint = c.primary, modifier = Modifier.size(48.dp))
            }
            Text("分区管家", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("启动前 Root 权限检测", color = c.onSurfaceVariant)
            when (root) {
                null -> { CircularProgressIndicator(); Text("正在请求并验证 su 权限…", color = c.onSurfaceVariant) }
                false -> {
                    Text("未取得可用的 Root 权限", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                    Text("请在 Root 管理器中允许本应用，然后重新检测。", color = c.onSurfaceVariant)
                    Button(onClick = onRetry) { Text("重新检测 Root") }
                }
                true -> Unit
            }
            Text("本应用不会在 Root 检测失败时开放分区读写功能。", color = c.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HomePage(onPartitions: () -> Unit, onFlash: () -> Unit) {
    val c = MaterialTheme.colorScheme
    LazyColumn(Modifier.fillMaxSize().background(c.background), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item(key = "home_header") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("PARTITION PILOT", color = c.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp); Text("分区管家", fontSize = 27.sp, fontWeight = FontWeight.Bold) }
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(c.surface).padding(10.dp)) { Icon(Icons.Rounded.Memory, null, tint = c.primary) }
            }
        }
        item(key = "home_hero") {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF286FE8), Color(0xFF5B9BFA), Color(0xFF5BC5C0)))).padding(20.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("设备分区管理", color = Color.White.copy(alpha = .82f), fontSize = 13.sp)
                    Text("读取 · 备份 · 校验", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("实时发现设备分区，不预设厂商分区表", color = Color.White.copy(alpha = .88f), fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.VerifiedUser, null, tint = Color.White, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Root 已验证", color = Color.White, fontSize = 12.sp) }
                }
            }
        }
        item(key = "home_actions") {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard(Modifier.weight(1f), "读取镜像", "分区列表 · 容量 · 备份", Icons.Rounded.Storage, Color(0xFF21866D), onPartitions)
                ActionCard(Modifier.weight(1f), "刷写分区", "镜像选择 · 校验 · 写入", Icons.Rounded.FlashOn, Color(0xFF326FCE), onFlash)
            }
        }
        item(key = "home_device_info") { DeviceInfoCard() }
        item(key = "home_backup_path") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.surface).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Folder, tint = Color(0xFF16866C), contentDescription = null)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("备份目录", fontWeight = FontWeight.SemiBold); Text("/storage/emulated/0/TNJZ", color = c.onSurfaceVariant, fontSize = 12.sp) }
                Icon(Icons.Rounded.CheckCircle, tint = Color(0xFF16866C), contentDescription = null)
            }
        }
        item(key = "home_safety_note") { Text("安全提示：动态逻辑分区、关键固件分区和无法识别的节点不会通过通用 raw 写入流程刷写。", color = c.onSurfaceVariant, fontSize = 12.sp) }
    }
}

@Composable
private fun ActionCard(modifier: Modifier, title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(modifier.clip(RoundedCornerShape(23.dp)).background(c.surface).clickable(onClick = onClick).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent, modifier = Modifier.size(25.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 11.sp, color = c.onSurfaceVariant, lineHeight = 16.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Icon(Icons.Rounded.ArrowForward, null, tint = accent) }
    }
}

@Composable
private fun DeviceInfoCard() {
    val c = MaterialTheme.colorScheme
    val context = LocalContext.current
    val displayName = runCatching { android.provider.Settings.Global.getString(context.contentResolver, android.provider.Settings.Global.DEVICE_NAME) }.getOrNull()
        ?.takeIf { it.isNotBlank() } ?: Build.MODEL
    val rows = listOf(
        "手机名称" to displayName,
        "制造商 / 型号" to "${Build.MANUFACTURER} ${Build.MODEL}",
        "设备代号" to Build.DEVICE,
        "内核版本" to System.getProperty("os.version", "未知"),
        "Android 版本" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "系统指纹" to Build.FINGERPRINT
    )
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp)).background(c.surface).padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.PhoneAndroid, null, tint = c.primary); Spacer(Modifier.width(8.dp)); Text("设备信息", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        rows.forEachIndexed { i, pair ->
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(pair.first, color = c.onSurfaceVariant, fontSize = 11.sp)
                Text(pair.second.ifBlank { "未知" }, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            if (i != rows.lastIndex) HorizontalDivider(color = c.surfaceVariant)
        }
    }
}

@Composable
private fun PartitionsPage(
    partitions: List<PartitionInfo>, selected: Set<String>, scanBusy: Boolean, message: String,
    onBack: () -> Unit, onRefresh: () -> Unit, onToggle: (PartitionInfo, Boolean) -> Unit,
    onBackup: () -> Unit, busy: Boolean, log: String
) {
    val c = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(c.background).padding(horizontal = 16.dp)) {
        PageHeader("读取镜像", onBack, onRefresh)
        Text("发现 ${partitions.size} 个常用分区（最多 145 个，按 A–Z 排序）", color = c.onSurfaceVariant, fontSize = 12.sp)
        if (scanBusy || busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (partitions.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(message.ifBlank { "点击刷新读取设备分区" }, color = c.onSurfaceVariant) }
        else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(partitions, key = { it.path }, contentType = { "partition_row" }) { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(c.surface).clickable { onToggle(p, p.path !in selected) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = p.path in selected, onCheckedChange = { onToggle(p, it) })
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold)
                        Text(p.path, fontSize = 10.sp, color = c.onSurfaceVariant)
                        Text("${formatBytes(p.sizeBytes)} · ${if (p.isLogical) "逻辑分区" else "块设备"}${if (p.readOnly) " · 只读/权限未知" else ""}", fontSize = 11.sp, color = c.onSurfaceVariant)
                        Text("刷入时间：Android 未提供可验证记录", fontSize = 10.sp, color = c.onSurfaceVariant)
                    }
                    if (p.canRawFlash) Text("可刷白名单", color = Color(0xFF16866C), fontSize = 10.sp)
                }
            }
        }
        Button(onClick = onBackup, enabled = selected.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Rounded.SaveAlt, null)
            Spacer(Modifier.width(8.dp)); Text("备份所选分区（${selected.size}）")
        }
        if (log.isNotBlank()) Text(log, Modifier.fillMaxWidth().padding(bottom = 12.dp), color = c.onSurfaceVariant, fontSize = 11.sp)
    }
}

@Composable
private fun FlashPage(
    partitions: List<PartitionInfo>, target: PartitionInfo?, image: ImageInfo?, typedConfirm: String,
    acknowledged: Boolean, busy: Boolean, log: String, onBack: () -> Unit, onTarget: (PartitionInfo) -> Unit,
    onPickImage: () -> Unit, onTyped: (String) -> Unit, onAck: (Boolean) -> Unit, onFlash: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(c.background).padding(horizontal = 16.dp)) {
        PageHeader("刷写分区", onBack, null)
        Text("目标分区", fontWeight = FontWeight.Bold)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(target?.let { "${it.name}  ·  ${it.path}" } ?: "选择已识别的分区", modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.ExpandMore, null)
            }
            DropdownMenu(expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 340.dp)) {
                partitions.forEach { p -> DropdownMenuItem(text = { Column { Text(p.name); Text(if (p.canRawFlash) "允许进入写入校验" else if (p.isLogical) "动态/逻辑分区：不支持 raw 写入" else "不在安全刷写名单", fontSize = 11.sp, color = c.onSurfaceVariant) } }, onClick = { onTarget(p); expanded = false }) }
            }
        }
        if (target != null) {
            Text("${target.path}\n容量：${formatBytes(target.sizeBytes)}", color = c.onSurfaceVariant, fontSize = 11.sp)
            if (!target.canRawFlash) WarningPanel("该分区不支持本应用的通用 raw 刷写流程。为避免设备无法启动，写入操作已禁用。")
        }
        Spacer(Modifier.height(14.dp))
        Text("镜像文件", fontWeight = FontWeight.Bold)
        Text("选择本地 .img 镜像文件，载入后自动计算 SHA-256。", color = c.onSurfaceVariant, fontSize = 12.sp)
        OutlinedButton(onClick = onPickImage, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("选择镜像文件")
        }
        if (image != null) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface).padding(13.dp)) {
                Text(image.file.name, fontWeight = FontWeight.SemiBold)
                Text("大小：${formatBytes(image.size)}", color = c.onSurfaceVariant, fontSize = 11.sp)
                Text("SHA-256：${image.sha256}", color = c.onSurfaceVariant, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        WarningPanel("刷写会直接修改底层块设备。请确认镜像与设备型号、分区类型和当前固件完全匹配。动态分区请使用官方 fastbootd 流程。")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(acknowledged, onCheckedChange = onAck)
            Text("我已确认镜像来源及目标分区正确", fontSize = 12.sp)
        }
        OutlinedTextField(value = typedConfirm, onValueChange = onTyped, modifier = Modifier.fillMaxWidth(), label = { Text("输入目标分区名称以确认") }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None))
        Button(
            onClick = onFlash,
            enabled = !busy && target?.canRawFlash == true && image != null && acknowledged && typedConfirm == target?.name,
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB93838))
        ) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Icon(Icons.Rounded.FlashOn, null); Spacer(Modifier.width(8.dp)); Text("写入分区") }
        if (log.isNotBlank()) Text(log, color = c.onSurfaceVariant, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp))
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit, onRefresh: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) }
        Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (onRefresh != null) IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null) }
    }
}

@Composable
private fun WarningPanel(text: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFFFE9E5).let { if (MaterialTheme.colorScheme.background.red < .3f) Color(0xFF482C2C) else it }).padding(13.dp), verticalAlignment = Alignment.Top) {
        Icon(Icons.Rounded.WarningAmber, null, tint = Color(0xFFB93838), modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp)); Text(text, color = if (MaterialTheme.colorScheme.background.red < .3f) Color(0xFFFFC6BD) else Color(0xFF8C302A), fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "未知大小"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble(); var index = 0
    while (value >= 1024 && index < units.lastIndex) { value /= 1024; index++ }
    return String.format(Locale.US, "%.2f %s", value, units[index])
}

private fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input -> val buffer = ByteArray(1024 * 1024); while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) } }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
