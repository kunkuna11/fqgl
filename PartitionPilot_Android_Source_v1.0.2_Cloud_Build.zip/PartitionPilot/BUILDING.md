# 构建说明

## 当前构建栈

| 组件 | 版本 |
|---|---|
| Build scripts | Groovy DSL (`build.gradle`) |
| Android Gradle Plugin | 8.9.2 |
| Gradle | 8.11.1 |
| Kotlin | 2.1.20 |
| JDK | 17 |
| Android SDK | 35 |
| Compose BOM | 2025.03.00 |

## Android Studio

1. 打开项目根目录 `PartitionPilot/`。
2. Gradle JDK 选择 JDK 17。
3. 安装 Android SDK Platform 35。
4. Gradle distribution 选择本机安装的 Gradle 8.11.1（本 ZIP 不携带 wrapper JAR）。
5. Sync 后执行 Build APK。

## 命令行

```bash
gradle --version
gradle wrapper --gradle-version 8.11.1  # 可选，仅首次生成 Wrapper
gradle assembleDebug
```

产物位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 注意

本次调整构建脚本和工具版本，不重写业务代码。当前交付环境没有 Android SDK/Gradle，因此无法在此处执行完整 Android 编译；请在具备 Android SDK 的 Android Studio 或 CI 环境构建。

本次 v1.0.1 更新只涉及 Compose 页面 Insets/返回键/列表展示与扫描过滤、列表滚动性能处理；原有 Root、备份和刷写核心流程未改写。
